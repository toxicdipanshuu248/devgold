(() => {
  'use strict';

  const STORAGE_KEY = 'devXGodWpQuettaSettings';
  const DEFAULTS = {
    enabled: false, preset: 'generator', gain: 4, clarity: 1.5, warmth: 0.5, air: 1,
    compression: 4, distortion: 0.02, hardClip: false, ceiling: -1.2,
    voiceStyle: 'normal', generatorEnabled: true, generatorLevel: 0.38,
    generatorRate: 52, generatorTexture: 0.16,
    extraMicEnabled: false, extraMicBoost: 1.5, extraMicFxLevel: 0,
    badMicVoiceFilterEnabled: false,
    badMicBands: [
      { enabled: false, frequency: 90, gain: 0, q: 0.8 },
      { enabled: false, frequency: 350, gain: 0, q: 0.8 },
      { enabled: false, frequency: 800, gain: 0, q: 0.8 },
      { enabled: false, frequency: 2000, gain: 0, q: 0.8 },
      { enabled: false, frequency: 7000, gain: 0, q: 0.8 },
      { enabled: false, frequency: 10000, gain: 0, q: 0.8 }
    ],
    autoLevelEnabled: true, autoLevelMax: 3, autoLevelTargetDb: -14
  };
  const PRESETS = {
    natural: {
      ...DEFAULTS, enabled: true, preset: 'natural', gain: 1, clarity: 0, warmth: 0,
      air: 0, compression: 2, distortion: 0, hardClip: false, ceiling: -1.2,
      voiceStyle: 'normal', generatorEnabled: false, generatorLevel: 0, generatorTexture: 0,
      autoLevelEnabled: false, autoLevelMax: 1, autoLevelTargetDb: -16
    },
    boost: {
      ...DEFAULTS, enabled: true, preset: 'boost', gain: 3.5, clarity: 1.5, warmth: 0.5,
      air: 1, compression: 4, distortion: 0, hardClip: false, ceiling: -1,
      voiceStyle: 'normal', generatorEnabled: false, generatorLevel: 0, generatorTexture: 0,
      autoLevelEnabled: true, autoLevelMax: 3, autoLevelTargetDb: -14
    },
    hifi: {
      ...DEFAULTS, enabled: true, preset: 'hifi', gain: 24, clarity: 4.5, warmth: 0.5,
      air: 3, compression: 8, distortion: 0.02, hardClip: false, ceiling: -0.7,
      voiceStyle: 'normal', generatorEnabled: false, generatorLevel: 0, generatorTexture: 0,
      autoLevelEnabled: true, autoLevelMax: 4, autoLevelTargetDb: -14
    },
    deep: {
      ...DEFAULTS, enabled: true, preset: 'deep', gain: 22, clarity: 5.5, warmth: 3,
      air: 2, compression: 8, distortion: 0.015, hardClip: false, ceiling: -0.8,
      voiceStyle: 'deep', generatorEnabled: false, generatorLevel: 0, generatorTexture: 0,
      autoLevelEnabled: true, autoLevelMax: 6, autoLevelTargetDb: -12
    },
    generator: {
      ...DEFAULTS, enabled: true, preset: 'generator', gain: 4, clarity: 1.5, warmth: 0.5,
      air: 1, compression: 4, distortion: 0.02, hardClip: false, ceiling: -1.2,
      voiceStyle: 'normal', generatorEnabled: true, generatorLevel: 0.38,
      generatorRate: 52, generatorTexture: 0.16,
      autoLevelEnabled: true, autoLevelMax: 3, autoLevelTargetDb: -14
    },
    laptop: {
      ...DEFAULTS, enabled: true, preset: 'laptop', gain: 8, clarity: 1.5, warmth: 0.5,
      air: 1.5, compression: 5, distortion: 0.03, hardClip: false, ceiling: -0.5,
      voiceStyle: 'normal', generatorEnabled: true, generatorLevel: 0.38,
      generatorRate: 52, generatorTexture: 0.16,
      autoLevelEnabled: true, autoLevelMax: 6, autoLevelTargetDb: -9
    },
    max: {
      ...DEFAULTS, enabled: true, preset: 'max', gain: 64, clarity: 9, warmth: 2,
      air: 5, compression: 20, distortion: 1, hardClip: true, ceiling: -0.1,
      voiceStyle: 'deep', generatorEnabled: true, generatorLevel: 1.35,
      generatorRate: 62, generatorTexture: 1,
      autoLevelEnabled: true, autoLevelMax: 24, autoLevelTargetDb: -6
    },
    attack: {
      ...DEFAULTS, enabled: true, preset: 'attack', gain: 64, clarity: 9, warmth: 0,
      air: 9, compression: 20, distortion: 1, hardClip: true, ceiling: -0.1,
      voiceStyle: 'normal', generatorEnabled: true, generatorLevel: 1.5,
      generatorRate: 70, generatorTexture: 1,
      autoLevelEnabled: true, autoLevelMax: 24, autoLevelTargetDb: -6
    },
    maxgen: {
      ...DEFAULTS, enabled: true, preset: 'maxgen', gain: 64, clarity: 9, warmth: 0,
      air: 9, compression: 1, distortion: 1, hardClip: true, ceiling: -0.1,
      voiceStyle: 'normal', generatorEnabled: true, generatorLevel: 1.5,
      generatorRate: 70, generatorTexture: 1,
      extraMicEnabled: true, extraMicBoost: 2,
      autoLevelEnabled: false, autoLevelMax: 24, autoLevelTargetDb: -6
    }
  };

  const ids = [
    'enabled','gain','clarity','warmth','air','compression','distortion','hardClip','ceiling',
    'voiceStyle','generatorEnabled','generatorLevel','generatorRate','generatorTexture',
    'extraMicEnabled','extraMicBoost','extraMicFxLevel','badMicVoiceFilterEnabled','autoLevelEnabled','autoLevelMax','autoLevelTargetDb',
    'gainValue','clarityValue','warmthValue','airValue','compressionValue','distortionValue','ceilingValue',
    'generatorLevelValue','generatorRateValue','generatorTextureValue','extraMicBoostValue','extraMicFxLevelValue','autoLevelMaxValue','autoLevelTargetDbValue',
    'statusCard','statusTitle','statusSubtitle','liveDot','profileNote'
  ];
  for (let index = 0; index < DEFAULTS.badMicBands.length; index += 1) {
    ids.push(`badMicBandEnabled${index}`, `badMicBandGain${index}`, `badMicBandGainValue${index}`,
      `badMicBandFrequency${index}`, `badMicBandFrequencyValue${index}`, `badMicBandFrequencyTitle${index}`,
      `badMicBandQ${index}`, `badMicBandQValue${index}`);
  }
  const elements = Object.fromEntries(ids.map((id) => [id, document.getElementById(id)]));
  const presetButtons = [...document.querySelectorAll('[data-preset]')];
  let settings = { ...DEFAULTS };
  let saveTimer = null;

  const clamp = (value, min, max, fallback) => {
    const number = Number(value);
    return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
  };
  function signedDb(value, suffix = 'dB') {
    const number = Number(value);
    return `${number > 0 ? '+' : ''}${number.toFixed(1)} ${suffix}`;
  }

  function normalize(raw) {
    const value = raw && typeof raw === 'object' ? raw : {};
    return {
      enabled: Boolean(value.enabled),
      preset: ['natural','boost','hifi','deep','generator','laptop','max','attack','maxgen','custom'].includes(value.preset) ? value.preset : DEFAULTS.preset,
      gain: clamp(value.gain, 1, 64, DEFAULTS.gain),
      clarity: clamp(value.clarity, -6, 9, DEFAULTS.clarity),
      warmth: clamp(value.warmth, -6, 6, DEFAULTS.warmth),
      air: clamp(value.air, -6, 9, DEFAULTS.air),
      compression: clamp(value.compression, 1, 20, DEFAULTS.compression),
      distortion: clamp(value.distortion, 0, 1, DEFAULTS.distortion),
      hardClip: Boolean(value.hardClip),
      ceiling: clamp(value.ceiling, -3, -0.1, DEFAULTS.ceiling),
      voiceStyle: ['normal','deep'].includes(value.voiceStyle) ? value.voiceStyle : DEFAULTS.voiceStyle,
      generatorEnabled: Boolean(value.generatorEnabled),
      generatorLevel: clamp(value.generatorLevel, 0, 1.5, DEFAULTS.generatorLevel),
      generatorRate: clamp(value.generatorRate, 32, 90, DEFAULTS.generatorRate),
      generatorTexture: clamp(value.generatorTexture, 0, 1, DEFAULTS.generatorTexture),
      extraMicEnabled: Boolean(value.extraMicEnabled),
      extraMicBoost: clamp(value.extraMicBoost, 1, 4, DEFAULTS.extraMicBoost),
      extraMicFxLevel: clamp(value.extraMicFxLevel, 0, 1, DEFAULTS.extraMicFxLevel),
      badMicVoiceFilterEnabled: Boolean(value.badMicVoiceFilterEnabled),
      badMicBands: DEFAULTS.badMicBands.map((fallback, index) => {
        const band = Array.isArray(value.badMicBands) && value.badMicBands[index] && typeof value.badMicBands[index] === 'object'
          ? value.badMicBands[index]
          : {};
        return {
          enabled: Boolean(band.enabled),
          frequency: clamp(band.frequency, 20, 10000, fallback.frequency),
          gain: clamp(band.gain, -5, 5, fallback.gain),
          q: clamp(band.q, 0.1, 4, fallback.q)
        };
      }),
      autoLevelEnabled: value.autoLevelEnabled === undefined ? DEFAULTS.autoLevelEnabled : Boolean(value.autoLevelEnabled),
      autoLevelMax: clamp(value.autoLevelMax, 1, 24, DEFAULTS.autoLevelMax),
      autoLevelTargetDb: clamp(value.autoLevelTargetDb, -24, -6, DEFAULTS.autoLevelTargetDb)
    };
  }

  function render() {
    elements.enabled.checked = settings.enabled;
    elements.hardClip.checked = Boolean(settings.hardClip);
    elements.generatorEnabled.checked = Boolean(settings.generatorEnabled);
    elements.extraMicEnabled.checked = Boolean(settings.extraMicEnabled);
    elements.badMicVoiceFilterEnabled.checked = Boolean(settings.badMicVoiceFilterEnabled);
    elements.autoLevelEnabled.checked = Boolean(settings.autoLevelEnabled);
    elements.voiceStyle.value = settings.voiceStyle;

    for (let index = 0; index < settings.badMicBands.length; index += 1) {
      const band = settings.badMicBands[index];
      elements[`badMicBandEnabled${index}`].checked = band.enabled;
      elements[`badMicBandGain${index}`].value = String(band.gain);
      elements[`badMicBandGainValue${index}`].textContent = signedDb(band.gain);
      elements[`badMicBandFrequency${index}`].value = String(band.frequency);
      elements[`badMicBandFrequencyValue${index}`].textContent = `${Math.round(band.frequency)} Hz`;
      elements[`badMicBandFrequencyTitle${index}`].textContent = `${Math.round(band.frequency)} Hz`;
      elements[`badMicBandQ${index}`].value = String(band.q);
      elements[`badMicBandQValue${index}`].textContent = Number(band.q).toFixed(1);
    }

    const sliders = ['gain','clarity','warmth','air','compression','distortion','ceiling','generatorLevel','generatorRate','generatorTexture','extraMicBoost','extraMicFxLevel','autoLevelMax','autoLevelTargetDb'];
    for (const key of sliders) {
      const input = elements[key];
      if (!input) continue;
      if (key === 'distortion' || key === 'extraMicFxLevel') input.value = String(Math.round(settings[key] * 100));
      else input.value = String(settings[key]);
    }

    const gainDb = 20 * Math.log10(Math.max(1, Number(settings.gain)));
    elements.gainValue.textContent = `${Number(settings.gain).toFixed(Number(settings.gain) >= 10 ? 0 : 1)}× · ${signedDb(gainDb)}`;
    elements.clarityValue.textContent = signedDb(settings.clarity);
    elements.warmthValue.textContent = signedDb(settings.warmth);
    elements.airValue.textContent = signedDb(settings.air);
    elements.compressionValue.textContent = `${Number(settings.compression).toFixed(Number.isInteger(Number(settings.compression)) ? 0 : 1)}×`;
    elements.distortionValue.textContent = `${Math.round(Number(settings.distortion) * 100)}%`;
    elements.ceilingValue.textContent = `${Number(settings.ceiling).toFixed(1)} dBFS`;
    elements.generatorLevelValue.textContent = `${Math.round(settings.generatorLevel * 100)}%`;
    elements.generatorRateValue.textContent = `${Math.round(settings.generatorRate)} Hz`;
    elements.generatorTextureValue.textContent = `${Math.round(settings.generatorTexture * 100)}%`;
    elements.extraMicBoostValue.textContent = `${Number(settings.extraMicBoost).toFixed(Number.isInteger(Number(settings.extraMicBoost)) ? 0 : 1)}×`;
    elements.extraMicFxLevelValue.textContent = `${Math.round(settings.extraMicFxLevel * 100)}%`;
    elements.autoLevelMaxValue.textContent = `${Number(settings.autoLevelMax).toFixed(Number.isInteger(Number(settings.autoLevelMax)) ? 0 : 1)}× extra`;
    elements.autoLevelTargetDbValue.textContent = `${Number(settings.autoLevelTargetDb).toFixed(0)} dBFS`;

    for (const button of presetButtons) button.classList.toggle('selected', button.dataset.preset === settings.preset);
    const extreme = settings.enabled && (settings.preset === 'laptop' || settings.hardClip || settings.gain >= 32 || settings.distortion >= 0.65 || (settings.generatorEnabled && settings.generatorLevel >= 0.7) || (settings.extraMicEnabled && settings.extraMicBoost >= 2) || (settings.autoLevelEnabled && settings.autoLevelMax >= 12));
    elements.statusCard.classList.toggle('on', settings.enabled);
    elements.statusCard.classList.toggle('extreme', extreme);
    elements.liveDot.classList.toggle('on', settings.enabled);
    const names = { hifi: 'HI-FI MAX', deep: 'CRYSTAL DEEP', generator: 'VOICE + GEN', laptop: 'LAPTOP LOUD', max: 'DEV X GOD / ULTRA MAX', attack: 'ATTACK MIC', maxgen: 'MAX GENERATOR' };
    elements.statusTitle.textContent = settings.enabled ? `${names[settings.preset] || 'MIC ENGINE'} ACTIVE` : 'MIC ENGINE OFF';

    if (!settings.enabled) elements.statusSubtitle.textContent = 'Choose a profile; mic effects remain off until enabled.';
    else if (settings.preset === 'hifi') elements.statusSubtitle.textContent = 'Loud and clear, with low distortion and some peak headroom.';
    else if (settings.preset === 'deep') elements.statusSubtitle.textContent = 'Fuller low tone with presence EQ; this is EQ shaping, not pitch shift.';
    else if (settings.preset === 'generator') elements.statusSubtitle.textContent = 'Balanced generator tone is mixed under your voice; lower the blend if it masks words.';
    else if (settings.preset === 'laptop') elements.statusSubtitle.textContent = 'Higher voice target + generator mix. Room noise may rise; lower gain if it clips or sounds rough.';
    else if (settings.preset === 'attack') elements.statusSubtitle.textContent = 'Aggressive hard-clip bite + maximum pulsing motor bed. Get consent first.';
    else if (settings.preset === 'maxgen') elements.statusSubtitle.textContent = 'Fixed post-lift gain; voice compression is off. Generator and voice share final peak control.';
    else if (extreme) elements.statusSubtitle.textContent = 'ULTRA lift / hard clip / generator bed. Warn the other caller first.';
    else elements.statusSubtitle.textContent = 'Your outgoing WhatsApp Web mic is being enhanced.';

    const notes = {
      natural: 'Natural keeps your voice close to the mic’s original tone.',
      boost: 'Boost adds level and presence for everyday calls.',
      hifi: 'Hi-Fi Max aims for a loud, clear voice with low distortion.',
      deep: 'Crystal Deep adds low warmth and clarity EQ; it does not perform true pitch/formant shifting.',
      generator: 'VOICE + GEN uses a restrained low-harmonic bed, softer noise, and shared peak control for a clearer blend.',
      laptop: 'LAPTOP LOUD raises the target and gain while keeping the generator bed modest. It can also raise room noise; use the blend slider if words lose clarity.',
      max: 'ULTRA GOD MODE keeps 64× gain and hard clipping with a boosted pulsing generator bed and up to 24× automatic lift.',
      attack: 'ATTACK MIC adds maximum bed level, brighter mids, hard clipping, and the strongest pulsing motor texture. Use carefully.',
      maxgen: 'Hard clipping + fixed post-lift gain. Optional Extra Mic-inspired multi-tap FX is separate; its Android OpenSL processing is only approximated. Auto-lift and voice compression are off, while the generator joins the shared output limiter.'
    };
    elements.profileNote.textContent = notes[settings.preset] || 'Manual settings are active. Auto-lift also raises background noise.';
  }

  async function persist() {
    try { await chrome.storage.local.set({ [STORAGE_KEY]: settings }); }
    catch (_) { elements.statusSubtitle.textContent = 'Could not save settings. Check extension storage permissions.'; }
  }
  function scheduleSave() { window.clearTimeout(saveTimer); saveTimer = window.setTimeout(persist, 70); }

  function updateBand(index, key, value) {
    const badMicBands = settings.badMicBands.map((band) => ({ ...band }));
    badMicBands[index][key] = value;
    settings = normalize({ ...settings, preset: 'custom', badMicBands });
    render();
    scheduleSave();
  }

  function updateFromSliders() {
    settings = normalize({
      ...settings,
      preset: 'custom',
      gain: elements.gain.value,
      clarity: elements.clarity.value,
      warmth: elements.warmth.value,
      air: elements.air.value,
      compression: elements.compression.value,
      distortion: Number(elements.distortion.value) / 100,
      ceiling: elements.ceiling.value,
      generatorLevel: elements.generatorLevel.value,
      generatorRate: elements.generatorRate.value,
      generatorTexture: elements.generatorTexture.value,
      extraMicBoost: elements.extraMicBoost.value,
      extraMicFxLevel: Number(elements.extraMicFxLevel.value) / 100,
      autoLevelMax: elements.autoLevelMax.value,
      autoLevelTargetDb: elements.autoLevelTargetDb.value
    });
    render();
    scheduleSave();
  }

  for (const input of [elements.gain,elements.clarity,elements.warmth,elements.air,elements.compression,elements.distortion,elements.ceiling,elements.generatorLevel,elements.generatorRate,elements.generatorTexture,elements.extraMicBoost,elements.extraMicFxLevel,elements.autoLevelMax,elements.autoLevelTargetDb]) {
    input.addEventListener('input', updateFromSliders);
  }
  elements.hardClip.addEventListener('change', () => { settings = normalize({ ...settings, preset: 'custom', hardClip: elements.hardClip.checked }); render(); scheduleSave(); });
  elements.generatorEnabled.addEventListener('change', () => { settings = normalize({ ...settings, preset: 'custom', generatorEnabled: elements.generatorEnabled.checked }); render(); scheduleSave(); });
  elements.extraMicEnabled.addEventListener('change', () => { settings = normalize({ ...settings, preset: 'custom', extraMicEnabled: elements.extraMicEnabled.checked }); render(); scheduleSave(); });
  elements.badMicVoiceFilterEnabled.addEventListener('change', () => { settings = normalize({ ...settings, preset: 'custom', badMicVoiceFilterEnabled: elements.badMicVoiceFilterEnabled.checked }); render(); scheduleSave(); });
  for (let index = 0; index < DEFAULTS.badMicBands.length; index += 1) {
    elements[`badMicBandEnabled${index}`].addEventListener('change', () => updateBand(index, 'enabled', elements[`badMicBandEnabled${index}`].checked));
    elements[`badMicBandGain${index}`].addEventListener('input', () => updateBand(index, 'gain', elements[`badMicBandGain${index}`].value));
    elements[`badMicBandFrequency${index}`].addEventListener('input', () => updateBand(index, 'frequency', elements[`badMicBandFrequency${index}`].value));
    elements[`badMicBandQ${index}`].addEventListener('input', () => updateBand(index, 'q', elements[`badMicBandQ${index}`].value));
  }
  elements.autoLevelEnabled.addEventListener('change', () => { settings = normalize({ ...settings, preset: 'custom', autoLevelEnabled: elements.autoLevelEnabled.checked }); render(); scheduleSave(); });
  elements.voiceStyle.addEventListener('change', () => { settings = normalize({ ...settings, preset: 'custom', voiceStyle: elements.voiceStyle.value }); render(); scheduleSave(); });
  elements.enabled.addEventListener('change', () => { settings = normalize({ ...settings, enabled: elements.enabled.checked }); render(); scheduleSave(); });

  for (const button of presetButtons) {
    button.addEventListener('click', () => {
      const name = button.dataset.preset;
      if (!PRESETS[name]) return;
      settings = normalize(PRESETS[name]);
      render();
      scheduleSave();
    });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes[STORAGE_KEY]?.newValue) { settings = normalize(changes[STORAGE_KEY].newValue); render(); }
  });
  chrome.storage.local.get(STORAGE_KEY).then((result) => { settings = normalize(result[STORAGE_KEY] || DEFAULTS); render(); }).catch(() => render());
})();
