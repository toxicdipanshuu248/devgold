# Target and source

This is **DEV X GOD WP — Quetta Edition v1.9.0**, a Manifest V3 extension for WhatsApp Web live-call audio, restricted to `https://web.whatsapp.com/*`.

**VOICE + GEN** provides a restrained generator underlay. **LAPTOP LOUD** offers stronger outgoing mic level (8× fixed gain, up to 6× auto-lift, −9 dBFS RMS target) while keeping the generator bed moderate. Voice, generator and Extra Mic echo returns pass through shared final peak control. Higher level may raise room noise or cause limiting; far-end loudness still depends on the browser, WhatsApp and receiving device.

On wider screens the popup expands to 780 px with a laptop-oriented profile/control layout; narrow screens remain responsive. Extra Mic remains a browser-side 19-tap approximation, not a bit-exact OpenSL clone. The Bad Mic-style filter/EQ approximations and fixed post-lift gain are retained.

Browser-free tests cover DSP routing/tap timing, the laptop preset and settings/config flow. No physical Quetta or desktop live call is certified by those tests.
