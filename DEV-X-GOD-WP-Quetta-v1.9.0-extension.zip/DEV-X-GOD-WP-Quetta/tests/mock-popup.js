'use strict';

// Dependency-free smoke test for profile controls and local settings.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
class ClassList{constructor(){this.items=new Set();}toggle(k,force){const add=force===undefined?!this.items.has(k):Boolean(force);add?this.items.add(k):this.items.delete(k);return add;}contains(k){return this.items.has(k);}}
class Element{constructor(doc,tag='div'){this.doc=doc;this.tagName=tag.toUpperCase();this.dataset={};this.classList=new ClassList();this.listeners={};this.value='';this.textContent='';this.checked=false;this._id='';}set id(v){this._id=v;if(v)this.doc.elements.set(v,this);}get id(){return this._id;}addEventListener(n,f){(this.listeners[n]||=[]).push(f);}dispatch(n,e={}){e.target||=this;for(const f of this.listeners[n]||[])f(e);}click(){this.dispatch('click');}}
class DocumentMock{constructor(){this.elements=new Map();this.presets=['natural','boost','hifi','deep','generator','laptop','max','attack','maxgen'].map(n=>{const b=new Element(this,'button');b.dataset.preset=n;return b;});const ids=['enabled','gain','clarity','warmth','air','compression','distortion','hardClip','ceiling','voiceStyle','generatorEnabled','generatorLevel','generatorRate','generatorTexture','extraMicEnabled','extraMicBoost','extraMicFxLevel','badMicVoiceFilterEnabled','autoLevelEnabled','autoLevelMax','autoLevelTargetDb','gainValue','clarityValue','warmthValue','airValue','compressionValue','distortionValue','ceilingValue','generatorLevelValue','generatorRateValue','generatorTextureValue','extraMicBoostValue','extraMicFxLevelValue','autoLevelMaxValue','autoLevelTargetDbValue','statusCard','statusTitle','statusSubtitle','liveDot','profileNote'];for(let i=0;i<6;i++)ids.push(`badMicBandEnabled${i}`,`badMicBandGain${i}`,`badMicBandGainValue${i}`,`badMicBandFrequency${i}`,`badMicBandFrequencyValue${i}`,`badMicBandFrequencyTitle${i}`,`badMicBandQ${i}`,`badMicBandQValue${i}`);for(const id of ids){const e=new Element(this,['enabled','hardClip','generatorEnabled','extraMicEnabled','badMicVoiceFilterEnabled','autoLevelEnabled',...Array.from({length:6},(_,i)=>`badMicBandEnabled${i}`)].includes(id)?'input':id==='voiceStyle'?'select':'div');e.id=id;}}getElementById(id){return this.elements.get(id)||null;}querySelectorAll(q){return q==='[data-preset]'?this.presets:[];}}
const doc=new DocumentMock(),store={},changed=[];const local={async get(k){return{[k]:store[k]};},async set(values){const c={};for(const[k,v]of Object.entries(values)){c[k]={oldValue:store[k],newValue:v};store[k]=v;}for(const f of changed)f(c,'local');}};
const chrome={storage:{local,onChanged:{addListener(f){changed.push(f);}}}};chrome.storage.local=local;let timer=0;
const sandbox={document:doc,chrome,window:{clearTimeout(){},setTimeout(fn){const id=++timer;queueMicrotask(fn);return id;}},console};
vm.createContext(sandbox);vm.runInContext(fs.readFileSync(`${__dirname}/../popup.js`,'utf8'),sandbox,{filename:'popup.js'});
const tick=()=>new Promise(r=>setImmediate(r));
(async()=>{
 await tick();
 assert.equal(doc.getElementById('enabled').checked,false,'default master state remains off');
 assert.equal(doc.presets.find(b=>b.dataset.preset==='generator').classList.contains('selected'),true,'fresh settings select the balanced voice + generator preset');
 assert.equal(doc.getElementById('generatorEnabled').checked,true,'balanced preset enables a restrained generator bed');
 assert.equal(doc.getElementById('generatorLevel').value,'0.38','balanced mix starts with a low generator level');
 assert.equal(doc.getElementById('generatorTexture').value,'0.16','balanced mix keeps generator noise subtle');
 assert.equal(doc.getElementById('badMicVoiceFilterEnabled').checked,false,'Bad Mic voice filter defaults off');
 assert.equal(doc.getElementById('extraMicFxLevel').value,'0','Extra Mic echo defaults off');
 assert.equal(doc.getElementById('extraMicFxLevelValue').textContent,'0%','Extra Mic echo output starts at zero');
 assert.equal(doc.getElementById('badMicBandEnabled0').checked,false,'EQ band defaults off');
 assert.equal(doc.getElementById('badMicBandFrequency0').value,'90','first EQ center follows its visible label');
 assert.equal(doc.getElementById('badMicBandQ0').value,'0.8','EQ Q starts at the visible 0.8 setting');
 assert.match(doc.getElementById('gainValue').textContent,/12\.0 dB/,'balanced default gain output shows its dB equivalent');
 doc.presets.find(b=>b.dataset.preset==='hifi').click();await tick();
 assert.equal(store.devXGodWpQuettaSettings.preset,'hifi');assert.equal(store.devXGodWpQuettaSettings.gain,24);assert.equal(store.devXGodWpQuettaSettings.hardClip,false);assert.equal(doc.getElementById('enabled').checked,true);
 doc.presets.find(b=>b.dataset.preset==='deep').click();await tick();
 assert.equal(store.devXGodWpQuettaSettings.preset,'deep');assert.equal(store.devXGodWpQuettaSettings.voiceStyle,'deep');assert.equal(store.devXGodWpQuettaSettings.warmth,3);
 doc.presets.find(b=>b.dataset.preset==='generator').click();await tick();
 assert.equal(store.devXGodWpQuettaSettings.preset,'generator');assert.equal(store.devXGodWpQuettaSettings.generatorEnabled,true);assert.equal(store.devXGodWpQuettaSettings.generatorLevel,0.38);assert.equal(store.devXGodWpQuettaSettings.generatorRate,52);assert.equal(store.devXGodWpQuettaSettings.generatorTexture,0.16);assert.equal(store.devXGodWpQuettaSettings.gain,4);assert.equal(store.devXGodWpQuettaSettings.hardClip,false);
 doc.presets.find(b=>b.dataset.preset==='laptop').click();await tick();
 assert.equal(store.devXGodWpQuettaSettings.preset,'laptop');assert.equal(store.devXGodWpQuettaSettings.gain,8);assert.equal(store.devXGodWpQuettaSettings.generatorEnabled,true);assert.equal(store.devXGodWpQuettaSettings.generatorLevel,0.38);assert.equal(store.devXGodWpQuettaSettings.autoLevelMax,6);assert.equal(store.devXGodWpQuettaSettings.autoLevelTargetDb,-9);assert.equal(store.devXGodWpQuettaSettings.hardClip,false);
 assert.equal(doc.getElementById('statusTitle').textContent,'LAPTOP LOUD ACTIVE','laptop preset clearly reports its higher-output profile');
 doc.presets.find(b=>b.dataset.preset==='max').click();await tick();
 assert.equal(store.devXGodWpQuettaSettings.preset,'max');assert.equal(store.devXGodWpQuettaSettings.gain,64);assert.equal(store.devXGodWpQuettaSettings.hardClip,true);assert.equal(store.devXGodWpQuettaSettings.ceiling,-0.1);assert.equal(store.devXGodWpQuettaSettings.generatorEnabled,true);assert.equal(store.devXGodWpQuettaSettings.generatorLevel,1.35);assert.equal(store.devXGodWpQuettaSettings.autoLevelEnabled,true);assert.equal(store.devXGodWpQuettaSettings.autoLevelMax,24);assert.equal(store.devXGodWpQuettaSettings.autoLevelTargetDb,-6);
 doc.presets.find(b=>b.dataset.preset==='attack').click();await tick();assert.equal(store.devXGodWpQuettaSettings.preset,'attack');assert.equal(store.devXGodWpQuettaSettings.generatorLevel,1.5);assert.equal(store.devXGodWpQuettaSettings.generatorRate,70);assert.equal(store.devXGodWpQuettaSettings.air,9);assert.equal(store.devXGodWpQuettaSettings.hardClip,true);
 doc.presets.find(b=>b.dataset.preset==='maxgen').click();await tick();assert.equal(store.devXGodWpQuettaSettings.preset,'maxgen');assert.equal(store.devXGodWpQuettaSettings.generatorLevel,1.5);assert.equal(store.devXGodWpQuettaSettings.extraMicEnabled,true);assert.equal(store.devXGodWpQuettaSettings.extraMicBoost,2);assert.equal(store.devXGodWpQuettaSettings.compression,1);assert.equal(store.devXGodWpQuettaSettings.autoLevelEnabled,false);
 doc.getElementById('extraMicBoost').value='3';doc.getElementById('extraMicBoost').dispatch('input');await tick();assert.equal(store.devXGodWpQuettaSettings.extraMicBoost,3,'Extra Mic fixed boost control persists');
 doc.getElementById('extraMicEnabled').checked=false;doc.getElementById('extraMicEnabled').dispatch('change');await tick();assert.equal(store.devXGodWpQuettaSettings.extraMicEnabled,false,'Extra Mic toggle persists');
 doc.getElementById('extraMicFxLevel').value='65';doc.getElementById('extraMicFxLevel').dispatch('input');await tick();assert.equal(store.devXGodWpQuettaSettings.extraMicFxLevel,0.65,'Extra Mic echo level persists as a normalized value');
 assert.equal(doc.getElementById('extraMicFxLevelValue').textContent,'65%','Extra Mic echo level output updates');
 doc.presets.find(b=>b.dataset.preset==='max').click();await tick();
 doc.getElementById('autoLevelMax').value='12';doc.getElementById('autoLevelMax').dispatch('input');await tick();assert.equal(store.devXGodWpQuettaSettings.autoLevelMax,12,'extra-lift cap control persists');
 doc.getElementById('autoLevelEnabled').checked=false;doc.getElementById('autoLevelEnabled').dispatch('change');await tick();assert.equal(store.devXGodWpQuettaSettings.autoLevelEnabled,false,'automatic-lift bypass persists');
 doc.getElementById('badMicVoiceFilterEnabled').checked=true;doc.getElementById('badMicVoiceFilterEnabled').dispatch('change');await tick();assert.equal(store.devXGodWpQuettaSettings.badMicVoiceFilterEnabled,true,'Bad Mic voice-filter approximation persists');
 doc.getElementById('badMicBandEnabled1').checked=true;doc.getElementById('badMicBandEnabled1').dispatch('change');await tick();assert.equal(store.devXGodWpQuettaSettings.badMicBands[1].enabled,true,'individual EQ-band enable persists');
 doc.getElementById('badMicBandGain1').value='3.5';doc.getElementById('badMicBandGain1').dispatch('input');await tick();assert.equal(store.devXGodWpQuettaSettings.badMicBands[1].gain,3.5,'EQ band level persists');
 doc.getElementById('badMicBandFrequency1').value='420';doc.getElementById('badMicBandFrequency1').dispatch('input');await tick();assert.equal(store.devXGodWpQuettaSettings.badMicBands[1].frequency,420,'EQ center frequency persists');
 doc.getElementById('badMicBandQ1').value='1.4';doc.getElementById('badMicBandQ1').dispatch('input');await tick();assert.equal(store.devXGodWpQuettaSettings.badMicBands[1].q,1.4,'EQ Q persists');
 assert.equal(doc.getElementById('badMicBandFrequencyTitle1').textContent,'420 Hz','band title reflects its tuned center');
 console.log('PASS: DEV X GOD WP popup mock — Bad Mic-style filter/EQ, Hi-Fi, VOICE + GEN, LAPTOP LOUD, ATTACK MIC, MAX GENERATOR, Extra Mic gain/echo, and auto-lift controls.');
})().catch(e=>{console.error(e);process.exitCode=1;});
