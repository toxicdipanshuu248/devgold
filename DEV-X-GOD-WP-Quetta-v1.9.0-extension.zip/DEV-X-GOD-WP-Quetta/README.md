# DEV X GOD WP — Quetta Edition (v1.9.0)

A responsive Manifest V3 extension for Chromium-based browsers (including **Quetta Browser on Android**), aimed at outgoing mic audio in live calls on `https://web.whatsapp.com/*`. Version 1.9.0 adds a dedicated **LAPTOP LOUD** voice-plus-generator profile for stronger outgoing mic level, alongside the balanced **VOICE + GEN** blend. Both use shared output peak control; the popup stays laptop-wide and responsive. Extra Mic and the v1.6.0-era EQ/filter controls remain.

APK analysis found Bad Mic's voice-filter setup uses a 400 Hz high-pass with native resonance 0.1; the 6 kHz low-pass object is initialized disabled. Quetta maps that to a WebAudio high-pass using Q 0.1, which is an approximation—not the native coefficient implementation or an exact APK sound match. The native first-run EQ has all six bands off and zero levels; the visible center labels are 90, 350, 800, 2,000, 7,000, and 10,000 Hz. The extension uses those as editable starting centers, with all bands off.

Disassembly of Extra Mic's stripped OpenSL callback shows 19 delayed taps spaced every 8 × 1,024-sample blocks at 48 kHz: about 171 ms through 3.24 s. The native first tap is fixed at 0.6 when FX is active; the remaining taps alternate 0.4/0.5 weights with a decaying envelope controlled by a scalar capped at 0.8. Quetta follows that timing and envelope in a memory-conscious WebAudio delay line, but smoothly scales the first tap for a usable 0–100% control (unlike the native step behavior). Browser timing/mixing differs, so this is an informed approximation, not bit-exact parity. The separate **fixed post-lift gain** remains simple gain, not the native FX. There is no Android system-wide mic effect.

## Install / use

1. Disable/remove older DEV X GOD WP, Micx, or MANSURI mic extensions in the target browser. Do not run multiple mic processors on the same page.
2. Unzip `DEV-X-GOD-WP-Quetta-v1.9.0-extension.zip` to a folder that stays on your device.
3. On a laptop in Chrome/Chromium, open `chrome://extensions`, enable **Developer mode**, choose **Load unpacked**, and select the unzipped folder containing `manifest.json`. In Quetta on Android, use its available local-extension flow if supported; some Quetta releases may require a store install instead.
4. Open or reload `web.whatsapp.com` in that browser. If the mobile layout does not expose calls, try **Desktop site** mode. Allow its normal microphone permission if the site offers calls.
5. Start a fresh live call. For a clean generator tone, choose **VOICE + GEN**: it starts with a restrained 38% bed and soft noise. For more outgoing level on a laptop, select **LAPTOP LOUD** (8× fixed gain, up to 6× auto-lift, −9 dBFS target) while retaining a restrained generator bed. This can also raise room noise; reduce the controls if the voice gets rough or clips. **MAX GENERATOR**, GOD MODE, and ATTACK MIC remain intentionally harsh options. The Extra Mic FX slider separately adds repeating echoes; the power switch bypasses all processing.

## Profiles and controls

- **Bad Mic-style voice filter:** optional 400 Hz WebAudio high-pass approximation (native resonance 0.1 mapped to WebAudio Q 0.1). The native low-pass object is set to 6 kHz but initialized disabled; coefficient generation and audible response are not reproduced exactly.
- **Six-band EQ:** independent enable and gain controls for bands initially centered at 90, 350, 800, 2,000, 7,000, and 10,000 Hz. Gain spans −5 to +5 dB; each center and Q can be adjusted. Defaults are neutral/off. The browser's biquad filters are not claimed to match Superpowered's implementation exactly.
- **MAX GENERATOR:** 64× fixed mic gain, a separate 2× fixed post-lift gain stage, unity-ratio voice compression, hard-clipped shaping, and a 150% pulsing motor/noise bed. Auto-lift is off. The generator is shaped on its own branch, then joins voice and echo at the shared final limiter; the aggressive settings can still clip or mask speech. Extra Mic FX remains off in this preset by default.
- **ATTACK MIC:** 64× fixed mic gain, up to 24× signal-dependent auto-lift, brighter presence/air, hard clipping, and the 150% motor bed. This is a best-effort approximation, not an exact copy of the APK's DSP.
- **GOD MODE:** 64× fixed gain, up to 24× extra auto-lift, hard clipping, maximum compression/saturation, and a 135% generator bed.
- **VOICE + GEN (balanced blend):** 4× voice gain with gentle EQ/compression, up to 3× auto-lift, a 38% low-harmonic motor bed, and 16% filtered noise. Voice and generator meet at the shared output limiter, helping the generator sit beneath speech. The **BLEND LEVEL** control ranges to 150%; high settings can still mask words.
- **LAPTOP LOUD:** 8× fixed gain, up to 6× extra auto-lift, a −9 dBFS RMS target, and the same restrained 38% generator blend. It is louder by design, but may raise room noise and trigger limiting/clipping. It cannot override WhatsApp/browser/receiving-device normalization, so far-end loudness is not guaranteed.
- **Fixed post-lift gain:** optional simple 1×–4× gain stage after auto-lift. MAX GENERATOR enables it at 2× and disables auto-lift by default. It is separate from the echo control.
- **Extra Mic FX approximation:** a 0–100% slider controls 19 delayed voice taps at 8-block intervals, about 171 ms through 3.24 s. The callback's first tap is fixed at 0.6 when enabled; its remaining taps alternate 0.4/0.5 and decay by the native FX scalar (capped at 0.8). The browser scales the first tap smoothly from zero for a predictable slider. That and browser timing/mixing mean this is not native OpenSL parity; high settings may mask speech.
- **Hi-Fi Max:** 24× fixed gain, lower distortion, no hard clip or generator bed, and more headroom. It remains distinct from the clipped profiles.
- **Crystal Deep:** low warmth and presence shaping for a deeper-feeling voice; it does not perform true pitch/formant shifting.

## Limits and safety

**0 dBFS is digital full scale.** The voice path uses compressor-based peak control; static clipping shapes the combined output. Neither guarantees louder audio at the far end. WhatsApp, the browser, network, and receiving-device processing can change the level. A loud motor bed, hard clipping, Extra Mic echo repeats, LAPTOP LOUD noise lift, or the MAX GENERATOR/ATTACK MIC mix may sound harsh or unintelligible and may mask words. Start low, get the other caller's consent before using loud/distorted modes, and reduce or bypass it if asked.

This package targets the WhatsApp Web live-call mic path when the page uses browser WebRTC capture. It does **not** affect the native WhatsApp Android app, phone calls, recorders, or other apps; voice-note behavior is not guaranteed. **No live call has been tested on Quetta or a desktop browser for this release.**

## Privacy and validation

Audio processing is local to the page. The extension does not record, transcribe, save, or upload call audio. It requests only local settings storage and the WhatsApp Web host permission; the browser/page remains in control of microphone permission.

On wider laptop screens, the popup expands to 780 px and lays out three wide profiles per row, denser EQ and blend controls; narrow screens keep the compact mobile layout.

Browser-free mocks validate the six-band EQ and filter routing/settings, Extra Mic tap timing/level/bypass, profile/control persistence, bridge normalization, generator/voice shared-limiter routing, the LAPTOP LOUD gain target/cap, fixed post-lift gain, auto-lift bounds/bypass, and cleanup. They do not replace a real call test. From this folder, run:

```sh
node tests/mock-dsp.js
node tests/mock-popup.js
node tests/mock-bridge.js
```
