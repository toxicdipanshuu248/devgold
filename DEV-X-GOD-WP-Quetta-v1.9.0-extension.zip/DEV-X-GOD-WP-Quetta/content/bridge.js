(() => {
  'use strict';

  // Relay only this extension's local controls to its page-world audio hook.
  const EXTENSION_CHANNEL = 'devxgodwp-quetta-extension';
  const PAGE_CHANNEL = 'devxgodwp-quetta-main';
  const STORAGE_KEY = 'devXGodWpQuettaSettings';
  const DEFAULTS = {
    enabled: false, gain: 64, clarity: 9, warmth: 0, air: 6,
    compression: 20, distortion: 1, hardClip: true, ceiling: -0.1,
    voiceStyle: 'normal', generatorEnabled: false, generatorLevel: 0.85,
    generatorRate: 52, generatorTexture: 0.75,
    extraMicEnabled: false, extraMicBoost: 1.5, extraMicFxLevel: 0,
    badMicVoiceFilterEnabled: false,
    badMicBands: [
      { enabled: false, frequency: 90, gain: 0, q: 0.8 },
      { enabled: false, frequency: 350, gain: 0, q: 0.8 },
      { enabled: false, frequency: 800, gain: 0, q: 0.8 },
      { enabled: false, frequency: 2000, gain: 0, q: 0.8 },
      { enabled: false, frequency: 7000, gain: 0, q: 0.8 },
      { enabled: false, frequency: 10000, gain: 0, q: 0.8 }
    ],
    autoLevelEnabled: true, autoLevelMax: 24, autoLevelTargetDb: -6
  };

  const clamp = (value, min, max, fallback) => {
    const number = Number(value);
    return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
  };

  function normalize(raw) {
    const value = raw && typeof raw === 'object' ? raw : {};
    return {
      enabled: Boolean(value.enabled),
      gain: clamp(value.gain, 1, 64, DEFAULTS.gain),
      clarity: clamp(value.clarity, -6, 9, DEFAULTS.clarity),
      warmth: clamp(value.warmth, -6, 6, DEFAULTS.warmth),
      air: clamp(value.air, -6, 9, DEFAULTS.air),
      compression: clamp(value.compression, 1, 20, DEFAULTS.compression),
      distortion: clamp(value.distortion, 0, 1, DEFAULTS.distortion),
      hardClip: Boolean(value.hardClip),
      ceiling: clamp(value.ceiling, -3, -0.1, DEFAULTS.ceiling),
      voiceStyle: ['normal','deep'].includes(value.voiceStyle) ? value.voiceStyle : DEFAULTS.voiceStyle,
      generatorEnabled: Boolean(value.generatorEnabled),
      generatorLevel: clamp(value.generatorLevel, 0, 1.5, DEFAULTS.generatorLevel),
      generatorRate: clamp(value.generatorRate, 32, 90, DEFAULTS.generatorRate),
      generatorTexture: clamp(value.generatorTexture, 0, 1, DEFAULTS.generatorTexture),
      extraMicEnabled: Boolean(value.extraMicEnabled),
      extraMicBoost: clamp(value.extraMicBoost, 1, 4, DEFAULTS.extraMicBoost),
      extraMicFxLevel: clamp(value.extraMicFxLevel, 0, 1, DEFAULTS.extraMicFxLevel),
      badMicVoiceFilterEnabled: Boolean(value.badMicVoiceFilterEnabled),
      badMicBands: DEFAULTS.badMicBands.map((fallback, index) => {
        const band = Array.isArray(value.badMicBands) && value.badMicBands[index] && typeof value.badMicBands[index] === 'object'
          ? value.badMicBands[index]
          : {};
        return {
          enabled: Boolean(band.enabled),
          frequency: clamp(band.frequency, 20, 10000, fallback.frequency),
          gain: clamp(band.gain, -5, 5, fallback.gain),
          q: clamp(band.q, 0.1, 4, fallback.q)
        };
      }),
      autoLevelEnabled: value.autoLevelEnabled === undefined ? DEFAULTS.autoLevelEnabled : Boolean(value.autoLevelEnabled),
      autoLevelMax: clamp(value.autoLevelMax, 1, 24, DEFAULTS.autoLevelMax),
      autoLevelTargetDb: clamp(value.autoLevelTargetDb, -24, -6, DEFAULTS.autoLevelTargetDb)
    };
  }

  async function relaySettings() {
    try {
      const result = await chrome.storage.local.get(STORAGE_KEY);
      window.postMessage({
        channel: EXTENSION_CHANNEL,
        type: 'CONFIG',
        payload: normalize(result[STORAGE_KEY] || DEFAULTS)
      }, location.origin);
    } catch (_) {
      // The page hook stays in dry/bypass mode if local settings cannot be read.
    }
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    if (event.data?.channel === PAGE_CHANNEL && event.data.type === 'REQUEST_CONFIG') relaySettings();
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes[STORAGE_KEY]) relaySettings();
  });

  relaySettings();
})();
