'use strict';

// Dependency-free smoke test for bridge normalization and auto-lift propagation.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const PAGE_CHANNEL = 'devxgodwp-quetta-main';
const EXTENSION_CHANNEL = 'devxgodwp-quetta-extension';
const STORAGE_KEY = 'devXGodWpQuettaSettings';
const origin = 'https://web.whatsapp.com';
const listeners = {};
const posts = [];
let storageListener;
let stored = {
  [STORAGE_KEY]: {
    enabled: true,
    gain: 64,
    generatorLevel: 99,
    extraMicEnabled: true,
    extraMicBoost: 9,
    extraMicFxLevel: 2,
    badMicVoiceFilterEnabled: true,
    badMicBands: [{ enabled: true, frequency: 30000, gain: 7, q: 0 }],
    autoLevelEnabled: false,
    autoLevelMax: 99,
    autoLevelTargetDb: -40
  }
};
const windowMock = {
  addEventListener(name, fn) { (listeners[name] ||= []).push(fn); },
  postMessage(message, targetOrigin) { posts.push({ message, targetOrigin }); }
};
const chromeMock = {
  storage: {
    local: { async get(key) { return { [key]: stored[key] }; } },
    onChanged: { addListener(fn) { storageListener = fn; } }
  }
};
const sandbox = {
  window: windowMock,
  chrome: chromeMock,
  location: { origin },
  Boolean,
  Number,
  Math,
  Object,
  console
};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(`${__dirname}/../content/bridge.js`, 'utf8'), sandbox, { filename: 'bridge.js' });
const tick = () => new Promise((resolve) => setImmediate(resolve));

(async () => {
  await tick();
  assert.equal(posts.length, 1, 'bridge sends its initial configuration');
  let payload = posts[0].message.payload;
  assert.equal(posts[0].message.channel, EXTENSION_CHANNEL);
  assert.equal(posts[0].targetOrigin, origin);
  assert.equal(payload.autoLevelEnabled, false, 'saved auto-lift bypass is preserved');
  assert.equal(payload.generatorLevel, 1.5, 'motor-bed level is clamped at the stronger 150% limit');
  assert.equal(payload.extraMicEnabled, true, 'Extra Mic toggle propagates');
  assert.equal(payload.extraMicBoost, 4, 'Extra Mic boost is capped at 4×');
  assert.equal(payload.extraMicFxLevel, 1, 'Extra Mic FX amount is normalized to 100%');
  assert.equal(payload.badMicVoiceFilterEnabled, true, 'Bad Mic voice filter selection propagates');
  assert.equal(payload.badMicBands.length, 6, 'all six EQ bands are present after normalization');
  assert.equal(payload.badMicBands[0].enabled, true, 'saved EQ band enable propagates');
  assert.equal(payload.badMicBands[0].frequency, 10000, 'EQ center frequency is clamped');
  assert.equal(payload.badMicBands[0].gain, 5, 'EQ gain is clamped to the supported range');
  assert.equal(payload.badMicBands[0].q, 0.1, 'EQ Q is clamped to the supported range');
  assert.equal(payload.badMicBands[1].frequency, 350, 'missing EQ bands use safe center defaults');
  assert.equal(payload.autoLevelMax, 24, 'extra-lift cap is clamped at 24×');
  assert.equal(payload.autoLevelTargetDb, -24, 'voice target stays within the supported dBFS range');

  listeners.message[0]({
    source: windowMock,
    origin,
    data: { channel: PAGE_CHANNEL, type: 'REQUEST_CONFIG' }
  });
  await tick();
  assert.equal(posts.length, 2, 'page config request is answered');
  assert.equal(posts[1].message.payload.autoLevelEnabled, false);

  stored = {
    [STORAGE_KEY]: {
      enabled: true,
      autoLevelEnabled: true,
      extraMicEnabled: true,
      extraMicBoost: 2.5,
      extraMicFxLevel: 0.65,
      autoLevelMax: 7.5,
      autoLevelTargetDb: -11
    }
  };
  storageListener({ [STORAGE_KEY]: { newValue: stored[STORAGE_KEY] } }, 'local');
  await tick();
  payload = posts.at(-1).message.payload;
  assert.equal(payload.autoLevelEnabled, true, 'storage changes propagate the auto-lift toggle');
  assert.equal(payload.badMicVoiceFilterEnabled, false, 'missing voice filter setting defaults off');
  assert.equal(payload.badMicBands[0].enabled, false, 'missing EQ band state defaults off');
  assert.equal(payload.badMicBands[0].frequency, 90, 'missing EQ band data uses the visible center');
  assert.equal(payload.extraMicEnabled, true, 'storage changes propagate Extra Mic state');
  assert.equal(payload.extraMicBoost, 2.5, 'storage changes propagate fixed Extra Mic gain');
  assert.equal(payload.extraMicFxLevel, 0.65, 'storage changes propagate Extra Mic echo amount');
  assert.equal(payload.autoLevelMax, 7.5, 'storage changes propagate a custom lift cap');
  assert.equal(payload.autoLevelTargetDb, -11, 'storage changes propagate the target');
  console.log('PASS: DEV X GOD WP Quetta bridge mock — Bad Mic-style EQ, auto-lift, Extra Mic gain/echo, and generator settings normalize and propagate to the page hook.');
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
