'use strict';

// Browser-free smoke test for the Quetta live-call WebAudio graph and auto-lift.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

class Param { constructor(value=0,min=-Infinity,max=Infinity){this.value=value;this.minValue=min;this.maxValue=max;} cancelScheduledValues(){} setTargetAtTime(v){this.value=v;} }
class Track { constructor(kind='audio',id='track'){this.kind=kind;this.id=id;this.readyState='live';this.enabled=true;this.listeners={};} addEventListener(n,f){(this.listeners[n]||=[]).push(f);} stop(){this.readyState='ended';} }
class Stream { constructor(tracks=[]){this.tracks=[...tracks];} getTracks(){return [...this.tracks];} getAudioTracks(){return this.tracks.filter(t=>t.kind==='audio');} getVideoTracks(){return this.tracks.filter(t=>t.kind==='video');} }
class Node { constructor(kind){this.kind=kind;this.connections=[];} connect(n){this.connections.push(n);return n;} disconnect(){this.connections=[];} addEventListener(){} }
class Gain extends Node { constructor(){super('gain');this.gain=new Param(1,-1000,1000);} }
class Biquad extends Node { constructor(){super('biquad');this.type='lowpass';this.frequency=new Param(350,10,24000);this.gain=new Param(0,-40,40);this.Q=new Param(1,.0001,1000);} }
class Compressor extends Node { constructor(){super('compressor');this.threshold=new Param(-24,-100,0);this.knee=new Param(30,0,40);this.ratio=new Param(12,1,20);this.attack=new Param(.003,.0001,1);this.release=new Param(.25,.01,1);} }
class Oscillator extends Node { constructor(){super('oscillator');this.type='sine';this.frequency=new Param(440,0,24000);this.started=false;} start(){this.started=true;} stop(){this.started=false;} }
class Analyzer extends Node { constructor(){super('analyser');this.fftSize=2048;this.level=.0008;} getByteTimeDomainData(a){a.fill(128);} getFloatTimeDomainData(a){a.fill(this.level);} }
class WaveShaper extends Node { constructor(){super('waveshaper');this.curve=null;} }
class BufferSource extends Node { constructor(){super('buffer-source');this.started=false;} start(){this.started=true;} stop(){this.started=false;} }
class Delay extends Node { constructor(maxDelayTime=1){super('delay');this.delayTime=new Param(0,0,maxDelayTime);this.maxDelayTime=maxDelayTime;} }
const listeners={};const intervals=new Map();let timer=0;
const windowMock={addEventListener(n,f){(listeners[n]||=[]).push(f);},postMessage(){},setInterval(fn,delay){const id=++timer;intervals.set(id,{fn,delay});return id;},clearInterval(id){intervals.delete(id);},setTimeout(){return ++timer;},clearTimeout(){}};
class AudioContextMock {
  constructor(){this.state='running';this.currentTime=0;this.sampleRate=48000;this.nodes=[];this.destinations=[];windowMock.audioContext=this;}
  add(n){this.nodes.push(n);return n;}
  createMediaStreamDestination(){const n=this.add(new Node('destination'));n.stream=new Stream([new Track('audio','processed')]);this.destinations.push(n);return n;}
  createGain(){return this.add(new Gain());} createBiquadFilter(){return this.add(new Biquad());}
  createDynamicsCompressor(){return this.add(new Compressor());} createWaveShaper(){return this.add(new WaveShaper());} createDelay(maxDelayTime=1){return this.add(new Delay(maxDelayTime));}
  createMediaStreamSource(s){const n=this.add(new Node('source'));n.stream=s;return n;}
  createAnalyser(){return this.add(new Analyzer());} createOscillator(){return this.add(new Oscillator());}
  createBuffer(c,l){const a=Array.from({length:c},()=>new Float32Array(l));return{getChannelData:i=>a[i]};}
  createBufferSource(){return this.add(new BufferSource());} resume(){return Promise.resolve();}
}
windowMock.AudioContext=AudioContextMock;
const mic=new Track('audio','mic'), camera=new Track('video','camera');
const sourceStream=new Stream([mic,camera]);
const navigatorMock={mediaDevices:{getUserMedia(){return Promise.resolve(sourceStream);}}};
const documentMock={addEventListener(){},querySelectorAll(){return[];}};
const sandbox={window:windowMock,navigator:navigatorMock,document:documentMock,location:{origin:'https://web.whatsapp.com'},MediaStream:Stream,Float32Array,Uint8Array,Math,Number,Object,Promise,Reflect,WeakSet,WeakMap,Set,Map,console:{warn(...args){throw new Error(`Unexpected fallback: ${args.join(' ')}`);}},setTimeout,clearTimeout};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(`${__dirname}/../content/main-world.js`,'utf8'),sandbox,{filename:'main-world.js'});
const sendConfig=(payload)=>{for(const fn of listeners.message||[])fn({source:windowMock,origin:'https://web.whatsapp.com',data:{channel:'devxgodwp-quetta-extension',type:'CONFIG',payload}});};
function check(value,label){assert.ok(value,label);}
function autoLevelTimer(){return [...intervals.entries()].find(([,entry])=>entry.delay===80);}
function tickAutoLevel(count=1){const timerEntry=autoLevelTimer();check(timerEntry,'auto-lift timer is running');for(let i=0;i<count;i++)timerEntry[1].fn();}

(async()=>{
  check(navigatorMock.mediaDevices.getUserMedia.__devXGodWpQuettaWrapped,'getUserMedia hook installed');
  const output=await navigatorMock.mediaDevices.getUserMedia({audio:true,video:true});
  check(output!==sourceStream,'processed output stream returned');
  check(output.getAudioTracks().length===1,'outgoing audio track generated');
  check(output.getVideoTracks()[0]===camera,'video is passed through unchanged');
  const context=windowMock.audioContext;
  const destination=context.destinations[0];
  const [dry,processed]=context.nodes.filter(n=>n.connections.includes(destination));
  check(dry?.kind==='gain'&&processed?.kind==='gain','dry and effects routes exist');
  const compressor=context.nodes.find(n=>n.kind==='compressor');
  const voiceFilterRoutes=context.nodes.filter(n=>n.kind==='gain'&&n.connections.includes(compressor));
  const voiceFilterDry=voiceFilterRoutes.find(n=>n.gain.value===1);
  const voiceFilterWet=voiceFilterRoutes.find(n=>n.gain.value===0);
  const badMicVoiceFilter=context.nodes.find(n=>n.kind==='biquad'&&n.type==='highpass'&&n.frequency.value===400);
  const eqCenters=[90,350,800,2000,7000,10000];
  const eqNodes=context.nodes.filter(n=>n.kind==='biquad'&&n.type==='peaking'&&eqCenters.includes(n.frequency.value));
  check(eqNodes.length===6,'six native-informed parametric EQ stages are created');
  check(eqNodes.every(n=>n.gain.value===0&&n.Q.value===0.8),'EQ defaults are off/neutral with the visible Q value');
  check(voiceFilterDry&&voiceFilterWet&&badMicVoiceFilter?.Q.value===0.1,'voice-filter approximation is bypassed by default');

  sendConfig({enabled:true,gain:64,clarity:9,warmth:2,air:5,compression:20,distortion:1,hardClip:true,ceiling:-0.1,voiceStyle:'deep',badMicVoiceFilterEnabled:true,badMicBands:[{}, {enabled:true,frequency:420,gain:3.5,q:1.4}],generatorEnabled:true,generatorLevel:1.35,generatorRate:62,generatorTexture:1,extraMicFxLevel:0.75,autoLevelEnabled:true,autoLevelMax:24,autoLevelTargetDb:-6});
  tickAutoLevel(12);
  check(dry.gain.value===0&&processed.gain.value===1,'GOD MODE selects processed path');
  check(context.nodes.some(n=>n.kind==='gain'&&Math.abs(n.gain.value-64)<.001),'64× max mic boost applied');
  check(context.nodes.some(n=>n.kind==='biquad'&&n.type==='peaking'&&n.gain.value===9),'max clarity EQ applied');
  check(context.nodes.some(n=>n.kind==='biquad'&&n.type==='highshelf'&&n.gain.value===5),'air EQ applied');
  check(context.nodes.some(n=>n.kind==='compressor'&&n.threshold.value===-30&&n.ratio.value===20),'max compressor profile applied');
  const waveShapers=context.nodes.filter(n=>n.kind==='waveshaper');
  const [shaper,generatorShaper,outputClipper]=waveShapers;
  const extraMic=context.nodes.find(n=>n.kind==='gain'&&n.connections.includes(shaper));
  const autoGain=context.nodes.find(n=>n.kind==='gain'&&n.connections.includes(extraMic));
  const voiceBoost=context.nodes.find(n=>n.kind==='gain'&&n.connections.includes(autoGain));
  const limiter=context.nodes.filter(n=>n.kind==='compressor').at(-1);
  const mixBus=context.nodes.find(n=>n.kind==='gain'&&n.connections.includes(outputClipper));
  const extraMicFxBus=context.nodes.find(n=>n.kind==='gain'&&n.connections.includes(limiter));
  const delayNodes=context.nodes.filter(n=>n.kind==='delay');
  const tapGains=context.nodes.filter(n=>n.kind==='gain'&&n.connections.includes(extraMicFxBus));
  const generatorPulse=context.nodes.find(n=>n.kind==='oscillator'&&n.type==='sine');
  const generatorNoise=context.nodes.find(n=>n.kind==='buffer-source');
  check(shaper?.curve?.[0]===-1&&shaper.curve.at(-1)===1,'hard-clip curve reaches digital full scale');
  check(autoGain?.gain.value>9&&autoGain.gain.value<=24,'automatic lift strongly raises quiet mic audio while staying within the 24× cap');
  const generatorBus=context.nodes.find(n=>n.kind==='gain'&&n.connections.includes(generatorShaper));
  check(limiter.threshold.value===-0.1,'GOD MODE limiter target is near full scale');
  check(context.nodes.some(n=>n.kind==='oscillator'&&n.type==='sawtooth'&&n.frequency.value===62),'motor fundamental is active');
  check(context.nodes.some(n=>n.kind==='oscillator'&&n.type==='square'&&n.frequency.value===124),'second motor harmonic is active');
  check(generatorBus?.gain.value===1.35,'GOD MODE has an increased motor-bed level');
  check(generatorBus?.connections.includes(generatorShaper),'motor bed has an independent saturation stage');
  check(generatorShaper.connections.includes(limiter)&&!generatorBus.connections.includes(limiter),'generator is shaped separately, then joins the shared voice limiter');
  check(extraMicFxBus.connections.includes(limiter),'Extra Mic echoes use the same shared peak control');
  check(limiter.connections.includes(mixBus)&&mixBus.connections.includes(outputClipper),'voice, generator, and echo blend through shared peak control and final shaping');
  check(extraMic.gain.value===1,'Extra Mic is unity unless enabled');
  check(delayNodes.length===19&&tapGains.length===19,'Extra Mic approximation creates the 19 taps seen in the native callback');
  const nativeBlockSeconds=1024/48000;
  check(delayNodes.every(n=>Math.abs(n.delayTime.value-8*nativeBlockSeconds)<1e-9),'each stage adds eight 1024-sample, 48 kHz blocks of delay');
  check(delayNodes.every(n=>n.maxDelayTime<0.2),'short delay stages avoid allocating 19 multi-second buffers on mobile devices');
  check(extraMic.connections.includes(delayNodes[0]),'Extra Mic delay line is fed from the processed voice');
  check(delayNodes.slice(0,-1).every((n,index)=>n.connections.includes(delayNodes[index+1])),'short delay stages form the native 8-block tap spacing');
  check(delayNodes.every((n,index)=>n.connections.includes(tapGains[index])),'each delay stage feeds its own tap gain');
  check(extraMicFxBus.connections.includes(limiter),'Extra Mic echoes join the shared final mix');
  const fxScalar=0.75*0.8;
  const expectedTapGains=[0.6*0.75];
  for(let echoIndex=2;echoIndex<=19;echoIndex++) expectedTapGains.push((echoIndex%2===0?0.4:0.5)*fxScalar**Math.floor(echoIndex/2));
  check(expectedTapGains.every((gain,index)=>Math.abs(tapGains[index].gain.value-gain)<1e-6),'Extra Mic levels follow the native first tap and alternating, recursively decaying tail');
  check(Math.abs(tapGains.at(-1).gain.value-0.5*fxScalar**9)<1e-6,'longest native-informed echo uses the ninth decay step');
  check(Math.abs(delayNodes.length*8*nativeBlockSeconds-3.242666666666667)<1e-6,'the 19th tap reaches about 3.24 seconds');
  check(context.nodes.some(n=>n.kind==='oscillator'&&n.type==='triangle'&&n.frequency.value===186),'third motor harmonic is active');
  check(context.nodes.some(n=>n.kind==='oscillator'&&n.type==='sawtooth'&&n.frequency.value===248),'fourth motor harmonic is active');
  check(context.nodes.some(n=>n.kind==='gain'&&Math.abs(n.gain.value-.405)<.001),'GOD MODE motor pulse depth is applied');
  check(context.nodes.some(n=>n.kind==='gain'&&Math.abs(n.gain.value-.32)<.001),'generator filtered-noise grit mix is applied');
  check(context.nodes.some(n=>n.kind==='biquad'&&n.type==='highpass'&&n.frequency.value===55),'deep voice uses lower high-pass EQ');
  check(badMicVoiceFilter?.frequency.value===400&&badMicVoiceFilter.Q.value===0.1,'Bad Mic-style HP uses the observed 400 Hz / Q 0.1 settings');
  check(voiceFilterDry.gain.value===0&&voiceFilterWet.gain.value===1,'voice-filter toggle selects the filtered route');
  const tunedEq=eqNodes.find(n=>n.frequency.value===420);
  check(tunedEq?.gain.value===3.5&&tunedEq.Q.value===1.4,'enabled six-band EQ applies its frequency, gain, and Q');

  sendConfig({enabled:true,badMicVoiceFilterEnabled:true,badMicBands:[{enabled:true,frequency:30000,gain:9,q:0}]});
  check(eqNodes.find(n=>n.frequency.value===10000)?.gain.value===5,'EQ gain and frequency inputs are safely clamped');
  check(eqNodes.find(n=>n.frequency.value===10000)?.Q.value===0.1,'EQ Q input is safely clamped');

  sendConfig({enabled:true,gain:8,clarity:1.5,warmth:0.5,air:1.5,compression:5,distortion:0.03,hardClip:false,ceiling:-0.5,voiceStyle:'normal',generatorEnabled:true,generatorLevel:0.38,generatorRate:52,generatorTexture:0.16,autoLevelEnabled:true,autoLevelMax:6,autoLevelTargetDb:-9});
  tickAutoLevel(12);
  check(voiceBoost.gain.value===8&&autoGain.gain.value>1&&autoGain.gain.value<=6,'LAPTOP LOUD applies stronger fixed gain with a bounded 6× extra lift');
  check(compressor.ratio.value===5&&limiter.threshold.value===-0.5,'LAPTOP LOUD keeps soft voice compression and its higher output target');
  check(generatorBus.gain.value===0.38,'LAPTOP LOUD keeps the generator restrained under the louder voice');

  sendConfig({enabled:true,gain:64,clarity:9,warmth:0,air:9,compression:20,distortion:1,hardClip:true,ceiling:-0.1,voiceStyle:'normal',generatorEnabled:true,generatorLevel:1.5,generatorRate:70,generatorTexture:1,autoLevelEnabled:true,autoLevelMax:24,autoLevelTargetDb:-6});
  tickAutoLevel(2);
  check(generatorBus.gain.value===1.5,'ATTACK MIC reaches the bounded 150% motor-bed setting');
  check(context.nodes.some(n=>n.kind==='oscillator'&&n.type==='sawtooth'&&n.frequency.value===70),'ATTACK MIC revs the motor fundamental');
  check(context.nodes.some(n=>n.kind==='oscillator'&&n.type==='triangle'&&n.frequency.value===210),'ATTACK MIC adds a call-band third harmonic');
  check(context.nodes.some(n=>n.kind==='oscillator'&&n.type==='sawtooth'&&n.frequency.value===280),'ATTACK MIC adds a call-band fourth harmonic');
  check(context.nodes.some(n=>n.kind==='gain'&&Math.abs(n.gain.value-.45)<.001&&n.connections.includes(generatorBus.gain)),'ATTACK MIC motor pulse modulates the bed within its cap');
  check(context.nodes.some(n=>n.kind==='biquad'&&n.type==='highshelf'&&n.gain.value===9),'ATTACK MIC uses brighter top-end attack shaping');

  sendConfig({enabled:true,gain:64,clarity:9,warmth:0,air:9,compression:1,distortion:1,hardClip:true,ceiling:-0.1,voiceStyle:'normal',generatorEnabled:true,generatorLevel:1.5,generatorRate:70,generatorTexture:1,extraMicEnabled:true,extraMicBoost:2,autoLevelEnabled:false,autoLevelMax:24,autoLevelTargetDb:-6});
  tickAutoLevel();
  check(autoGain.gain.value===1,'MAX GENERATOR disables auto-lift so the fixed voice gain does not pump');
  check(context.nodes.find(n=>n.kind==='compressor').ratio.value===1,'MAX GENERATOR bypasses voice compressor gain reduction');
  check(extraMic.gain.value===2,'MAX GENERATOR applies a separate fixed Extra Mic boost');
  check(generatorBus.gain.value===1.5,'MAX GENERATOR bed remains at its configured level');
  check(generatorBus.connections.includes(generatorShaper)&&generatorShaper.connections.includes(limiter),'MAX GENERATOR uses the shaped generator branch and shared limiter');
  check(generatorPulse.started&&context.nodes.some(n=>n.kind==='oscillator'&&n.type==='triangle'&&n.frequency.value===210),'MAX GENERATOR keeps its motor oscillators running');

  sendConfig({enabled:true,gain:1,clarity:0,warmth:0,air:0,compression:2,distortion:0,hardClip:false,ceiling:-1,voiceStyle:'normal',generatorEnabled:false,generatorLevel:0,generatorRate:52,generatorTexture:0,autoLevelEnabled:true,autoLevelMax:24,autoLevelTargetDb:-6});
  tickAutoLevel(12);
  check(autoGain.gain.value>2,'quiet signal builds extra auto-lift before cap reduction');
  sendConfig({enabled:true,gain:1,clarity:0,warmth:0,air:0,compression:2,distortion:0,hardClip:false,ceiling:-1,voiceStyle:'normal',generatorEnabled:false,generatorLevel:0,generatorRate:52,generatorTexture:0,autoLevelEnabled:true,autoLevelMax:2,autoLevelTargetDb:-6});
  check(autoGain.gain.value===2,'lowering the lift cap immediately clamps an existing gain');
  tickAutoLevel();
  check(autoGain.gain.value<=2,'auto-lift never exceeds the configured cap');
  const levelAnalyser=context.nodes.find(n=>n.kind==='analyser');
  levelAnalyser.level=0.00001;
  sendConfig({enabled:true,gain:64,clarity:9,warmth:0,air:6,compression:20,distortion:1,hardClip:true,ceiling:-0.1,voiceStyle:'normal',generatorEnabled:false,generatorLevel:0,generatorRate:52,generatorTexture:0,autoLevelEnabled:true,autoLevelMax:24,autoLevelTargetDb:-6});
  tickAutoLevel(80);
  check(autoGain.gain.value<1.01,'near-silence gate lets the extra lift return close to unity');
  levelAnalyser.level=0.0008;

  sendConfig({enabled:true,gain:24,clarity:4.5,warmth:.5,air:3,compression:8,distortion:.02,hardClip:false,ceiling:-.7,voiceStyle:'normal',generatorEnabled:false,generatorLevel:0,generatorRate:52,generatorTexture:0,autoLevelEnabled:true,autoLevelMax:4,autoLevelTargetDb:-14});
  tickAutoLevel(12);
  check(dry.gain.value===0&&processed.gain.value===1,'Hi-Fi profile stays on processed route');
  check(autoGain.gain.value>1&&autoGain.gain.value<=4,'Hi-Fi Max retains a lower bounded quiet-mic lift');
  check(context.nodes.some(n=>n.kind==='gain'&&n.gain.value===24),'Hi-Fi gain applied');
  check(context.nodes.some(n=>n.kind==='biquad'&&n.type==='lowshelf'&&n.gain.value===.5),'Hi-Fi warmth EQ applied');
  check(shaper.curve && shaper.curve[2047] > -0.01 && shaper.curve[2048] < 0.01,'Hi-Fi saturation curve stays close to linear around zero');
  check(limiter.threshold.value===-.7,'Hi-Fi peak target applied');
  check(generatorBus.gain.value===0,'Hi-Fi profile mutes the generator bed');
  check(context.nodes.some(n=>n.kind==='biquad'&&n.type==='highpass'&&n.frequency.value===75),'natural voice style restores standard high-pass');

  sendConfig({enabled:true,gain:24,clarity:4.5,warmth:.5,air:3,compression:8,distortion:.02,hardClip:false,ceiling:-.7,voiceStyle:'normal',generatorEnabled:false,generatorLevel:0,generatorRate:52,generatorTexture:0,autoLevelEnabled:false,autoLevelMax:4,autoLevelTargetDb:-14});
  tickAutoLevel();
  check(autoGain.gain.value===1,'automatic-lift bypass returns gain to unity');

  sendConfig({enabled:false,gain:64,clarity:9,warmth:0,air:6,compression:20,distortion:1,hardClip:true,ceiling:-.1,voiceStyle:'normal',generatorEnabled:false,generatorLevel:0,generatorRate:52,generatorTexture:0});
  check(dry.gain.value===1&&processed.gain.value===0,'master switch restores dry/unprocessed audio');
  check(generatorBus.gain.value===0&&extraMic.gain.value===1&&tapGains.every(n=>n.gain.value===0),'master bypass disables generator, Extra Mic gain, and echo taps');
  const levelTimerId=autoLevelTimer()[0];
  output.getAudioTracks()[0].stop();
  check(!intervals.has(levelTimerId),'call cleanup stops the automatic-lift timer');
  check(mic.readyState==='ended','stopping processed audio releases the original mic track');
  check(!generatorPulse.started&&!generatorNoise.started,'cleanup stops continuous motor/noise sources');
  check(delayNodes.every(n=>n.connections.length===0),'call cleanup disconnects the Extra Mic delay line');
  console.log('PASS: DEV X GOD WP Quetta DSP mock — Bad Mic-style 6-band EQ/filter, bounded auto-lift, fixed Extra Mic boost/19-tap echo, LAPTOP LOUD mix, blended generator, MAX GENERATOR, bypass/cleanup, and Hi-Fi.');
})().catch((error)=>{console.error(error);process.exitCode=1;});
